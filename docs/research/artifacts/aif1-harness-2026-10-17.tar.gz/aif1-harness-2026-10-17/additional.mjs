import assert from "node:assert/strict";
import { server, message, history, save, verifyWire } from "./common.mjs";
import * as framework from "./framework/adapter.mjs";
const s = await server();
try {
  const c = s.add(() => ({
    output: [message("Synthetic bounded summary/result.")],
  }));
  const a = framework.makeAgent(c.baseURL, { compact: true, limit: 1 });
  const r = await a.invoke({ messages: history });
  verifyWire(c.entry.requests);
  assert.equal(c.entry.requests.length, 2);
  await save("additional-results.json", {
    test: "createAgent runLimit=1 + summarization",
    observedHttpRequests: c.entry.requests.length,
    reportedThreadModelCalls: r.threadModelCallCount,
    interpretation:
      "modelCallLimitMiddleware does not count separate summarization model call; shared provider admission must wrap both",
    wire: c.entry.requests,
  });
  console.log(
    "Verified two actual HTTP requests with runLimit=1, including compaction.",
  );
} finally {
  await s.close();
}
