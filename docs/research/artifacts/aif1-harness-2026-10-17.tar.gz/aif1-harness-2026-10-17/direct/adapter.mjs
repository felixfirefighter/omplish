import OpenAI from "openai";
import { key, loopbackFetch, readSpec, writeSpec, task } from "../common.mjs";
export function makeModel(baseURL) {
  return new OpenAI({
    apiKey: key,
    baseURL,
    maxRetries: 0,
    timeout: 2000,
    fetch: loopbackFetch,
  });
}
export async function invoke(client, messages, options = {}) {
  let input = [...messages];
  let calls = 0;
  const tools = [readSpec, ...(options.gateway ? [writeSpec] : [])];
  if (options.pending) input = options.pending;
  if (options.resume) {
    const last = input.at(-1);
    const output =
      options.resume === "approve"
        ? await options.gateway.execute(JSON.parse(last.arguments))
        : { outcome: "rejected" };
    input.push({
      type: "function_call_output",
      call_id: last.call_id,
      output: JSON.stringify(output),
    });
  }
  while (calls++ < 6) {
    const r = await client.responses.create(
      {
        model: "gpt-5.6",
        store: false,
        input,
        max_output_tokens: 1024,
        tools,
        parallel_tool_calls: false,
      },
      { signal: options.signal },
    );
    input.push(...r.output);
    const requested = r.output.filter((x) => x.type === "function_call");
    if (!requested.length) return { messages: input, text: r.output_text };
    for (const c of requested) {
      if (c.name === "set_priority" && options.gateway) {
        if (options.approval) return { messages: input, pending: input };
        const result = await options.gateway.execute(JSON.parse(c.arguments));
        input.push({
          type: "function_call_output",
          call_id: c.call_id,
          output: JSON.stringify(result),
        });
      } else if (c.name === "read_task") {
        const args = JSON.parse(c.arguments);
        if (args.id !== task.id) throw Error("not owned");
        input.push({
          type: "function_call_output",
          call_id: c.call_id,
          output: JSON.stringify(task),
        });
      } else throw Error("Unknown tool");
    }
  }
  throw Error("Model budget exceeded");
}
export async function stream(client) {
  let text = "";
  const events = await client.responses.create({
    model: "gpt-5.6",
    store: false,
    input: [{ role: "user", content: "stream" }],
    max_output_tokens: 1024,
    stream: true,
  });
  for await (const e of events)
    if (e.type === "response.output_text.delta") text += e.delta;
  return text;
}
export async function compact(client, history) {
  const r = await client.responses.create({
    model: "gpt-5.6",
    store: false,
    input: [
      {
        role: "user",
        content: `Summarize: ${JSON.stringify(history.slice(0, -4))}`,
      },
    ],
    max_output_tokens: 2048,
  });
  return invoke(client, [
    { role: "system", content: r.output_text },
    ...history.slice(-4),
  ]);
}
