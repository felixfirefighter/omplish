import assert from "node:assert/strict";
import { performance } from "node:perf_hooks";
import {
  server,
  call,
  message,
  verifyWire,
  gateway,
  history,
  metrics,
  save,
} from "./common.mjs";
import * as direct from "./direct/adapter.mjs";
import * as framework from "./framework/adapter.mjs";
const results = {
  date: "2026-10-17",
  scope: "synthetic local HTTP; not semantic or production evaluation",
  tests: [],
  timing: {},
  storage: {},
  wire: [],
};
const s = await server();
const prompt = [
  { role: "user", content: "Read task-1, then describe its current priority." },
];
const readHandler = (body, n) => ({
  output: n === 1 ? [call()] : [message("task-1 priority is none.")],
});
const writeArgs = { id: "task-1", priority: "high", operationId: "op-1" };
const writeHandler = (body, n) => ({
  output:
    n === 1
      ? [call("set_priority", writeArgs)]
      : [message("Fixture command result.")],
});
function run(kind, c, messages = prompt, options = {}) {
  return kind === "direct"
    ? direct.invoke(direct.makeModel(c.baseURL), messages, options)
    : framework.invoke(framework.makeAgent(c.baseURL, options), messages, {
        configurable: { thread_id: options.threadId ?? "thread-fixture" },
        signal: options.signal,
      });
}
async function test(name, fn) {
  try {
    const detail = await fn();
    results.tests.push({ name, pass: true, detail });
    console.log("PASS", name);
  } catch (e) {
    results.tests.push({ name, pass: false, error: e.message, stack: e.stack });
    console.log("FAIL", name, e.message);
  }
}
function retainWire(name, c) {
  verifyWire(c.entry.requests);
  results.wire.push({ name, requests: c.entry.requests });
}
function bytes(value) {
  if (value instanceof Uint8Array) return value.byteLength;
  if (value === null || value === undefined) return 0;
  if (typeof value === "string") return Buffer.byteLength(value);
  if (typeof value !== "object") return Buffer.byteLength(String(value));
  return Object.entries(value).reduce(
    (n, [k, v]) => n + Buffer.byteLength(k) + bytes(v),
    0,
  );
}
function rawStored(saver) {
  return JSON.stringify(
    { storage: saver.storage, writes: saver.writes },
    (_, v) => (v instanceof Uint8Array ? Buffer.from(v).toString("utf8") : v),
  );
}
try {
  for (const kind of ["direct", "framework"]) {
    await test(`${kind}:tool-continuation`, async () => {
      const c = s.add(readHandler);
      const r = await run(kind, c);
      assert.equal(c.entry.requests.length, 2);
      assert.ok(JSON.stringify(r).includes("task-1 priority is none."));
      retainWire(`${kind}:tool`, c);
      return { requests: 2 };
    });
    await test(`${kind}:streaming`, async () => {
      const c = s.add(() => ({ output: [message("Stream fixture.")] }));
      const r =
        kind === "direct"
          ? await direct.stream(direct.makeModel(c.baseURL))
          : await framework.stream(c.baseURL);
      assert.equal(r, "Stream fixture.");
      retainWire(`${kind}:stream`, c);
      return { requests: c.entry.requests.length };
    });
    await test(`${kind}:503-no-hidden-retry`, async () => {
      const c = s.add(() => ({ status: 503 }));
      await assert.rejects(run(kind, c));
      assert.equal(c.entry.requests.length, 1);
      retainWire(`${kind}:503`, c);
      return { requests: 1 };
    });
    await test(`${kind}:timeout`, async () => {
      const c = s.add(async () => {
        await new Promise((r) => setTimeout(r, 2200));
        return { output: [message()] };
      });
      const start = performance.now();
      await assert.rejects(run(kind, c));
      const elapsed = performance.now() - start;
      assert.ok(elapsed < 3000);
      assert.equal(c.entry.requests.length, 1);
      retainWire(`${kind}:timeout`, c);
      return { elapsedMs: elapsed, requests: 1 };
    });
    await test(`${kind}:abort`, async () => {
      const c = s.add(async () => {
        await new Promise((r) => setTimeout(r, 1000));
        return { output: [message()] };
      });
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 60);
      const start = performance.now();
      try {
        await assert.rejects(run(kind, c, prompt, { signal: ctrl.signal }));
      } finally {
        clearTimeout(timer);
      }
      const elapsed = performance.now() - start;
      assert.ok(elapsed < 1000);
      assert.equal(c.entry.requests.length, 1);
      retainWire(`${kind}:abort`, c);
      return { elapsedMs: elapsed, requests: 1 };
    });
    await test(`${kind}:unknown-tool`, async () => {
      const c = s.add((body, n) => ({
        output:
          n === 1
            ? [call("execute_sql", { query: "delete everything" })]
            : [message("Tool not available.")],
      }));
      const g = gateway();
      let outcome;
      try {
        outcome = await run(kind, c, prompt, { gateway: g });
      } catch (e) {
        outcome = e.message;
      }
      assert.equal(g.effects, 0);
      retainWire(`${kind}:unknown`, c);
      return {
        effects: 0,
        requests: c.entry.requests.length,
        outcome: JSON.stringify(outcome).slice(0, 240),
      };
    });
    await test(`${kind}:model-call-limit`, async () => {
      const c = s.add(() => ({ output: [call()] }));
      await assert.rejects(run(kind, c));
      assert.equal(c.entry.requests.length, 6);
      retainWire(`${kind}:limit`, c);
      return { requests: 6 };
    });
    await test(`${kind}:approve-and-reject`, async () => {
      const details = [];
      for (const decision of ["approve", "reject"]) {
        const c = s.add(writeHandler);
        const g = gateway();
        let resumed;
        if (kind === "direct") {
          const client = direct.makeModel(c.baseURL);
          const pending = await direct.invoke(client, prompt, {
            gateway: g,
            approval: true,
          });
          assert.ok(pending.pending);
          assert.equal(g.effects, 0);
          resumed = await direct.invoke(client, [], {
            gateway: g,
            pending: pending.pending,
            resume: decision,
          });
        } else {
          const saver = new framework.MemorySaver();
          const a = framework.makeAgent(c.baseURL, {
            gateway: g,
            approval: true,
            saver,
          });
          const cfg = { configurable: { thread_id: `thread-${decision}` } };
          const pending = await a.invoke({ messages: prompt }, cfg);
          assert.ok(pending.__interrupt__?.length);
          assert.equal(g.effects, 0);
          resumed = await a.invoke(
            new framework.Command({
              resume: {
                decisions: [
                  {
                    type: decision,
                    ...(decision === "reject"
                      ? { message: "Not approved" }
                      : {}),
                  },
                ],
              },
            }),
            cfg,
          );
        }
        assert.equal(g.effects, decision === "approve" ? 1 : 0);
        assert.ok(resumed);
        retainWire(`${kind}:${decision}`, c);
        details.push({
          decision,
          effects: g.effects,
          requests: c.entry.requests.length,
        });
      }
      return details;
    });
    await test(`${kind}:duplicate-and-commit-replay`, async () => {
      const g = gateway();
      let fail = true;
      const original = g.execute;
      g.execute = async (input) => {
        const result = await original(input);
        if (fail) {
          fail = false;
          throw Error("simulated response loss after commit");
        }
        return result;
      };
      const c = s.add(writeHandler);
      try {
        await run(kind, c, prompt, { gateway: g });
      } catch {}
      assert.equal(g.effects, 1);
      const c2 = s.add(writeHandler);
      await run(kind, c2, prompt, { gateway: g });
      assert.equal(g.effects, 1);
      assert.equal(g.receipts.length, 1);
      await assert.rejects(g.execute({ ...writeArgs, priority: "low" }));
      retainWire(`${kind}:replay-first`, c);
      retainWire(`${kind}:replay-second`, c2);
      return {
        effects: 1,
        receipts: 1,
        note: "In-memory application gateway supplies idempotency; new-run replay, no SQL claim",
      };
    });
    await test(`${kind}:compaction-wire`, async () => {
      const c = s.add((body, n) => ({
        output: [
          message(
            n === 1
              ? "Summary: synthetic fixture; task-1 remains canonical."
              : "History compacted.",
          ),
        ],
      }));
      let saver;
      let r;
      if (kind === "direct")
        r = await direct.compact(direct.makeModel(c.baseURL), history);
      else {
        saver = new framework.MemorySaver();
        r = await run(kind, c, history, {
          compact: true,
          saver,
          threadId: "history",
        });
      }
      assert.equal(c.entry.requests.length, 2);
      retainWire(`${kind}:compaction`, c);
      assert.equal(c.entry.requests[0].body.max_output_tokens, 2048);
      const before = Buffer.byteLength(JSON.stringify(history));
      const after = Buffer.byteLength(
        JSON.stringify(c.entry.requests[1].body.input),
      );
      assert.ok(after < before / 3);
      if (saver) {
        results.storage.compaction = {
          originalMessageJsonBytes: before,
          modelInputBytes: after,
          checkpointPayloadBytes: bytes(saver.storage) + bytes(saver.writes),
          oldMarkerRetained: rawStored(saver).includes("SYNTHETIC_HISTORY_0"),
        };
      }
      return {
        originalMessageJsonBytes: before,
        modelInputBytes: after,
        requests: 2,
      };
    });
  }
  await test("framework:checkpoint-retention-and-delete", async () => {
    const c = s.add((body, n) => ({
      output: n === 1 ? [call()] : [message("Checkpoint result.")],
      metadata: { fixture_raw: "RAW_PROVIDER_MARKER" },
    }));
    const saver = new framework.MemorySaver();
    const a = framework.makeAgent(c.baseURL, { saver });
    const cfg = { configurable: { thread_id: "retention" } };
    await a.invoke({ messages: prompt }, cfg);
    const snapshots = [];
    for await (const row of saver.list(cfg)) snapshots.push(row);
    const payloadBytes = bytes(saver.storage) + bytes(saver.writes);
    const containsRawProviderOutput = rawStored(saver).includes(
      "RAW_PROVIDER_MARKER",
    );
    assert.ok(containsRawProviderOutput);
    assert.equal(
      rawStored(saver).includes("fixture-not-a-real-provider-key"),
      false,
    );
    await saver.deleteThread("retention");
    assert.equal(await saver.getTuple(cfg), undefined);
    results.storage.retention = {
      snapshots: snapshots.length,
      payloadBytes,
      containsRawProviderOutput,
      afterDeleteBytes: bytes(saver.storage) + bytes(saver.writes),
    };
    return results.storage.retention;
  });
  await test("framework:checkpoint-post-commit-failure", async () => {
    class FailSaver extends framework.MemorySaver {
      armed = true;
      async put(config, checkpoint, metadata, versions) {
        if (
          this.armed &&
          checkpoint.channel_values.messages?.some(
            (m) => m._getType?.() === "tool" && m.name === "set_priority",
          )
        ) {
          this.armed = false;
          throw Error("synthetic checkpoint failure after tool");
        }
        return super.put(config, checkpoint, metadata, versions);
      }
    }
    const saver = new FailSaver();
    const c = s.add(writeHandler);
    const g = gateway();
    const a = framework.makeAgent(c.baseURL, { saver, gateway: g });
    const cfg = { configurable: { thread_id: "failure" }, durability: "sync" };
    await assert.rejects(a.invoke({ messages: prompt }, cfg));
    assert.equal(g.effects, 1);
    const resumed = await a.invoke(null, cfg);
    assert.equal(g.effects, 1);
    assert.ok(resumed);
    retainWire("framework:checkpoint-failure", c);
    return {
      effects: 1,
      checkpointFailureInjected: true,
      requests: c.entry.requests.length,
      note: "Same-process MemorySaver; idempotent in-memory gateway, not durable SQL restart",
    };
  });
  // Warmed microbenchmark: equivalent two-call tool loop without persistence in both variants.
  const samples = { direct: [], framework: [] };
  for (let i = 0; i < 35; i++) {
    for (const kind of i % 2
      ? ["framework", "direct"]
      : ["direct", "framework"]) {
      const c = s.add(readHandler);
      const start = performance.now();
      await run(kind, c);
      const duration = performance.now() - start;
      if (i >= 5) samples[kind].push(duration);
    }
  }
  for (const kind of Object.keys(samples))
    results.timing[kind] = {
      ...metrics(samples[kind]),
      samples: samples[kind],
      workload:
        "two loopback calls, one read tool; no persistence; 5warmups+30runs",
    };
  results.summary = {
    passed: results.tests.filter((x) => x.pass).length,
    failed: results.tests.filter((x) => !x.pass).length,
  };
  await save(new URL("./results.json", import.meta.url), results);
  console.log(
    JSON.stringify(
      {
        summary: results.summary,
        timing: results.timing,
        storage: results.storage,
      },
      null,
      2,
    ),
  );
} finally {
  await s.close();
}
