#!/bin/sh
set -eu
cd "$(dirname "$0")"
export LANGSMITH_TRACING=false
export LANGCHAIN_TRACING_V2=false
node evaluate.mjs > evaluation.log 2>&1
node additional.mjs > additional.log 2>&1
node measure.mjs > measurements.log 2>&1
