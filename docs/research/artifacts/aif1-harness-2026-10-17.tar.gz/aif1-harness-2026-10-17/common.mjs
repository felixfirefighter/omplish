import http from "node:http";
import assert from "node:assert/strict";
import { writeFile } from "node:fs/promises";

export const key = "fixture-not-a-real-provider-key";
export const task = {
  id: "task-1",
  title: "Draft proposal",
  version: 1,
  priority: "none",
};
export function response(output, id = "resp_fixture") {
  return {
    id,
    object: "response",
    created_at: 1,
    status: "completed",
    error: null,
    incomplete_details: null,
    instructions: null,
    max_output_tokens: 1024,
    model: "gpt-5.6",
    output,
    parallel_tool_calls: false,
    previous_response_id: null,
    reasoning: { effort: null, summary: null },
    store: false,
    temperature: 1,
    text: { format: { type: "text" } },
    tool_choice: "auto",
    tools: [],
    top_p: 1,
    truncation: "disabled",
    usage: {
      input_tokens: 0,
      output_tokens: 0,
      total_tokens: 0,
      input_tokens_details: { cached_tokens: 0 },
      output_tokens_details: { reasoning_tokens: 0 },
    },
    metadata: {},
  };
}
export function message(text = "Fixture result.") {
  return {
    type: "message",
    id: "msg_fixture",
    status: "completed",
    role: "assistant",
    content: [{ type: "output_text", text, annotations: [], logprobs: [] }],
  };
}
export function call(name = "read_task", args = { id: "task-1" }) {
  return {
    type: "function_call",
    id: "fc_fixture",
    status: "completed",
    call_id: "call_fixture",
    name,
    arguments: JSON.stringify(args),
  };
}
export async function server() {
  const cases = new Map();
  let seq = 0;
  const srv = http.createServer(async (req, res) => {
    let raw = "";
    for await (const chunk of req) raw += chunk;
    const body = JSON.parse(raw);
    const name = req.url.split("/")[1];
    const entry = cases.get(name);
    if (!entry) {
      res.writeHead(400);
      res.end("{}");
      return;
    }
    entry.requests.push({ path: req.url, bytes: Buffer.byteLength(raw), body });
    if (entry.requests.length > 8) {
      res.writeHead(429);
      res.end(
        JSON.stringify({
          error: { message: "fixture request budget", type: "fixture_error" },
        }),
      );
      return;
    }
    const result = await entry.handler(body, entry.requests.length);
    if (res.destroyed) return;
    if (result.status) {
      res.writeHead(result.status, { "content-type": "application/json" });
      res.end(
        JSON.stringify({
          error: { message: "synthetic failure", type: "server_error" },
        }),
      );
      return;
    }
    const out = response(
      result.output ?? [message()],
      `${name}_resp_${entry.requests.length}`,
    );
    if (result.metadata) out.metadata = result.metadata;
    if (body.stream) {
      res.writeHead(200, {
        "content-type": "text/event-stream",
        "cache-control": "no-cache",
      });
      let sequence_number = 0;
      const emit = (event) =>
        res.write(
          `data: ${JSON.stringify({ ...event, sequence_number: sequence_number++ })}\n\n`,
        );
      emit({
        type: "response.created",
        response: { ...out, status: "in_progress", output: [] },
      });
      for (
        let output_index = 0;
        output_index < out.output.length;
        output_index++
      ) {
        const item = out.output[output_index];
        emit({
          type: "response.output_item.added",
          output_index,
          item: { ...item, status: "in_progress", content: [] },
        });
        for (
          let content_index = 0;
          content_index < item.content.length;
          content_index++
        ) {
          const part = item.content[content_index];
          emit({
            type: "response.content_part.added",
            output_index,
            content_index,
            item_id: item.id,
            part: { ...part, text: "" },
          });
          emit({
            type: "response.output_text.delta",
            output_index,
            content_index,
            item_id: item.id,
            delta: part.text,
          });
          emit({
            type: "response.output_text.done",
            output_index,
            content_index,
            item_id: item.id,
            text: part.text,
          });
          emit({
            type: "response.content_part.done",
            output_index,
            content_index,
            item_id: item.id,
            part,
          });
        }
        emit({ type: "response.output_item.done", output_index, item });
      }
      emit({ type: "response.completed", response: out });
      res.end();
    } else {
      res.writeHead(200, { "content-type": "application/json" });
      res.end(JSON.stringify(out));
    }
  });
  await new Promise((resolve, reject) => {
    srv.once("error", reject);
    srv.listen(0, "127.0.0.1", resolve);
  });
  return {
    cases,
    add(handler) {
      const name = `case${seq++}`;
      const entry = { requests: [], handler };
      cases.set(name, entry);
      return {
        baseURL: `http://127.0.0.1:${srv.address().port}/${name}/v1`,
        entry,
      };
    },
    close() {
      srv.closeAllConnections();
      return new Promise((r) => srv.close(r));
    },
  };
}
export function loopbackFetch(url, options) {
  const u = new URL(typeof url === "string" ? url : url.url);
  assert.equal(u.hostname, "127.0.0.1");
  return fetch(url, options);
}
export function verifyWire(requests) {
  assert.ok(requests.length > 0);
  for (const { body, path } of requests) {
    assert.ok(path.endsWith("/responses"));
    assert.equal(body.store, false);
    assert.ok(!body.previous_response_id);
    assert.ok(
      Number.isInteger(body.max_output_tokens) &&
        body.max_output_tokens <= 4096,
    );
  }
}
export function gateway() {
  let effects = 0;
  const receipts = new Map();
  let deleted = false;
  return {
    async execute(input) {
      if (deleted) throw Error("deleted");
      const prior = receipts.get(input.operationId);
      if (prior) {
        assert.equal(prior.input, JSON.stringify(input));
        return prior.result;
      }
      const result = { outcome: "committed", taskId: "task-1", version: 2 };
      receipts.set(input.operationId, { input: JSON.stringify(input), result });
      effects++;
      return result;
    },
    delete() {
      deleted = true;
    },
    get effects() {
      return effects;
    },
    get receipts() {
      return [...receipts.values()];
    },
  };
}
export const readSpec = {
  type: "function",
  name: "read_task",
  description: "Read exactly one authorized fixture task",
  strict: true,
  parameters: {
    type: "object",
    properties: { id: { type: "string" } },
    required: ["id"],
    additionalProperties: false,
  },
};
export const writeSpec = {
  type: "function",
  name: "set_priority",
  description: "Apply reviewed fixture priority",
  strict: true,
  parameters: {
    type: "object",
    properties: {
      id: { type: "string" },
      priority: { type: "string" },
      operationId: { type: "string" },
    },
    required: ["id", "priority", "operationId"],
    additionalProperties: false,
  },
};
export const history = Array.from({ length: 40 }, (_, i) => ({
  role: i % 2 ? "assistant" : "user",
  content: `SYNTHETIC_HISTORY_${i} ${"context ".repeat(80)}`,
}));
export function metrics(values) {
  const sorted = [...values].sort((a, b) => a - b);
  return {
    median: sorted[Math.floor(sorted.length / 2)],
    p95: sorted[Math.ceil(sorted.length * 0.95) - 1],
    min: sorted[0],
    max: sorted.at(-1),
  };
}
export async function save(path, data) {
  await writeFile(path, JSON.stringify(data, null, 2) + "\n");
}
