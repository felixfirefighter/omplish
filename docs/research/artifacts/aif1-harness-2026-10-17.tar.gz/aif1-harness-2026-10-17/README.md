# Omplish AIF1 synthetic harness evaluation

Research artifact only. Run no production data or real keys. Nothing here imports Omplish runtime.

1. Use Node24.14.1 and npm11.11.0 (actual npm version is saved separately; exact package locks define dependencies).
2. In `direct` and `framework`, run `npm ci --ignore-scripts --no-audit --no-fund`.
3. From this directory run `./run.sh`. Requires binding127.0.0.1; model fetch rejects all other hosts. Tracing is disabled.
4. Read PROTOCOL.md, results.json, additional-results.json, measurements.json and evaluation.log.
5. Optional strict API surface check: `tsc --noEmit --strict --target ES2022 --module NodeNext --moduleResolution NodeNext --skipLibCheck framework/typecheck.ts` with TypeScript6.0.3.
6. Refresh advisory evidence with `npm audit --omit=dev --json` inside each dependency directory.

The Responses fixture scripts outputs independently of semantic input and only implements exercised protocol fields. Tests verify transport/control flow, not live provider compatibility, model quality, prompt injection resistance, authorization policy, production SQL correctness, undo, persistent restart, installer size or deploy readiness. `gateway()` and direct approval state are small in-memory test fixtures, not production implementations. Default graph checkpoint raw-output retention is intentionally detected; a passing diagnostic is not a passing privacy gate.

Initial failed experiment logs are retained to show fixture parser/type-inference corrections; final results.json and typecheck.log are authoritative for this run.
