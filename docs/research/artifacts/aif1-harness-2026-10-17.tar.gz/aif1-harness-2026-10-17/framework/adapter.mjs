import {
  createAgent,
  tool,
  humanInTheLoopMiddleware,
  summarizationMiddleware,
  modelCallLimitMiddleware,
} from "langchain";
import { ChatOpenAI } from "@langchain/openai";
import { MemorySaver, Command } from "@langchain/langgraph";
import { z } from "zod";
import { key, loopbackFetch, task } from "../common.mjs";
export { MemorySaver, Command };
export function makeModel(baseURL, maxTokens = 1024) {
  return new ChatOpenAI({
    model: "gpt-5.6",
    apiKey: key,
    configuration: { baseURL, fetch: loopbackFetch },
    useResponsesApi: true,
    modelKwargs: { store: false },
    maxTokens,
    supportsStrictToolCalling: true,
    maxRetries: 0,
    timeout: 2000,
  });
}
export function makeAgent(baseURL, options = {}) {
  const tools = [
    tool(
      async ({ id }) => {
        if (id !== task.id) throw Error("not owned");
        return JSON.stringify(task);
      },
      {
        name: "read_task",
        description: "Read exactly one authorized fixture task",
        schema: z.object({ id: z.string() }),
      },
    ),
  ];
  if (options.gateway)
    tools.push(
      tool(
        async (args) => JSON.stringify(await options.gateway.execute(args)),
        {
          name: "set_priority",
          description: "Apply reviewed fixture priority",
          schema: z.object({
            id: z.string(),
            priority: z.string(),
            operationId: z.string(),
          }),
        },
      ),
    );
  const middleware = [
    modelCallLimitMiddleware({
      runLimit: options.limit ?? 6,
      exitBehavior: "error",
    }),
  ];
  if (options.approval)
    middleware.push(
      humanInTheLoopMiddleware({
        interruptOn: {
          set_priority: { allowedDecisions: ["approve", "reject"] },
        },
      }),
    );
  if (options.compact)
    middleware.push(
      summarizationMiddleware({
        model: makeModel(baseURL, 2048),
        trigger: { messages: 12 },
        keep: { messages: 4 },
      }),
    );
  return createAgent({
    model: makeModel(baseURL),
    tools,
    middleware,
    checkpointer: options.saver,
  });
}
export async function invoke(agent, messages, options = {}) {
  return agent.invoke({ messages }, { ...options, recursionLimit: 30 });
}
export async function stream(baseURL) {
  let text = "";
  for await (const chunk of await makeModel(baseURL).stream("stream"))
    text +=
      typeof chunk.content === "string"
        ? chunk.content
        : chunk.content
            .filter((x) => x.type === "text")
            .map((x) => x.text)
            .join("");
  return text;
}
