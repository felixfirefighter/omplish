import {
  createAgent,
  tool,
  humanInTheLoopMiddleware,
  summarizationMiddleware,
  modelCallLimitMiddleware,
} from "langchain";
import { ChatOpenAI } from "@langchain/openai";
import { MemorySaver, Command } from "@langchain/langgraph";
import { z } from "zod";
const model = new ChatOpenAI({
  model: "gpt-5.6",
  apiKey: "fixture-only",
  useResponsesApi: true,
  modelKwargs: { store: false },
  supportsStrictToolCalling: true,
  maxTokens: 1024,
  maxRetries: 0,
  timeout: 2000,
});
const inputSchema = z.object({ id: z.string() });
const agent = createAgent({
  model,
  tools: [
    tool(async (input: z.infer<typeof inputSchema>) => input.id, {
      name: "read_task",
      description: "fixture",
      schema: inputSchema,
    }),
  ],
  middleware: [
    modelCallLimitMiddleware({ runLimit: 6, exitBehavior: "error" }),
    humanInTheLoopMiddleware({
      interruptOn: { read_task: { allowedDecisions: ["approve", "reject"] } },
    }),
    summarizationMiddleware({
      model,
      trigger: { messages: 12 },
      keep: { messages: 4 },
    }),
  ],
  checkpointer: new MemorySaver(),
});
async function signaturesOnly() {
  const config = { configurable: { thread_id: "fixture" }, recursionLimit: 30 };
  await agent.invoke(
    { messages: [{ role: "user", content: "fixture" }] },
    config,
  );
  await agent.invoke(
    new Command({ resume: { decisions: [{ type: "approve" }] } }),
    config,
  );
}
void signaturesOnly;
