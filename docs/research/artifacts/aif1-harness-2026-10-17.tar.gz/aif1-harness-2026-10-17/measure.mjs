import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";
import { readFile, readdir, stat, writeFile } from "node:fs/promises";
import { metrics } from "./common.mjs";
const out = {};
async function byteSize(dir) {
  let n = 0;
  for (const e of await readdir(dir, { withFileTypes: true })) {
    const p = `${dir}/${e.name}`;
    if (e.isDirectory()) n += await byteSize(p);
    else if (e.isFile()) n += (await stat(p)).size;
  }
  return n;
}
for (const name of ["direct", "framework"]) {
  const dir = new URL(`./${name}/`, import.meta.url);
  const lock = JSON.parse(await readFile(new URL("package-lock.json", dir)));
  const entries = Object.entries(lock.packages).filter(([k]) => k);
  const imports = [];
  for (let i = 0; i < 5; i++) {
    const child = spawnSync(
      process.execPath,
      [
        "--input-type=module",
        "-e",
        `const before=process.memoryUsage();const t=performance.now();await import('./adapter.mjs');console.log(JSON.stringify({ms:performance.now()-t,rss:process.memoryUsage().rss,rssDelta:process.memoryUsage().rss-before.rss}))`,
      ],
      { cwd: dir, encoding: "utf8" },
    );
    if (child.status !== 0) throw Error(child.stderr);
    imports.push(JSON.parse(child.stdout));
  }
  const audits = JSON.parse(await readFile(new URL("audit.json", dir)));
  const versions = entries.map(([path, x]) => ({
    path,
    version: x.version,
    license: x.license,
    integrity: x.integrity,
  }));
  out[name] = {
    installedPackages: entries.length,
    logicalBytes: await byteSize(fileURLToPath(new URL("node_modules", dir))),
    importMs: metrics(imports.map((x) => x.ms)),
    rss: metrics(imports.map((x) => x.rss)),
    rssDelta: metrics(imports.map((x) => x.rssDelta)),
    imports,
    audit: audits.metadata,
    licenses: [...new Set(entries.map(([, x]) => x.license))],
    versions,
  };
}
await writeFile("measurements.json", JSON.stringify(out, null, 2) + "\n");
console.log(
  JSON.stringify(
    Object.fromEntries(
      Object.entries(out).map(([k, { versions, ...v }]) => [k, v]),
    ),
    null,
    2,
  ),
);
